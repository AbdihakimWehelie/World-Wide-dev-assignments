<?php // sqltest.php

   require "header.php";
?>




<html>
<body>
    

<h2>  
<p>Phone Number:(905) 828-2237</p>

  
<p>Address: 3897 Seebring Cres 
Mississauga, ON 
L5L 3X8(Mississauga ,Ontario)  </p>

<p>Email: jobS@gmail.ca</p>


</h2>
    
    
    
    
</body>
</html>



<?php // sqltest.php

   require "footer.php";
?>
