<?php // sqltest.php

   require "header.php";
?>




<html>
<body>
    

<h2>  
<p>Welcome the aptly named Job search site: JobS.</p>
<p>Here can either find jobs or employ people depending on your needs.</p>


</h2>
    
    
    
    
</body>
</html>



<?php // sqltest.php

   require "footer.php";
?>
