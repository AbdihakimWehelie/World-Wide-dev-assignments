

function switchlight(flag) {                                            

    if (flag =='on')
document.getElementById('myImage').src='pic_bulbon.gif'
    
    
    else
document.getElementById('myImage').src='pic_bulboff.gif'

    
} 