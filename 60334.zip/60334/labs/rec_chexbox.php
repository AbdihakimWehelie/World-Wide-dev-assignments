<?php


    $_GET['colors']; // gets value from [colors] in send_checkbox_all.html
    
    
    foreach($_GET['colors'] as $color){
        
        echo $color;
        
    }


?>