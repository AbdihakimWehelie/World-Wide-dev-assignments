<html>
<body>





   
    
Welcome <?php echo $_POST["fname"];?>. <br/> 

Your age is <?php echo $_POST["age"];?>
 
 
 
</body>    
</html>