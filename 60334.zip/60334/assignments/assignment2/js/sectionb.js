function browse(){



document.getElementById("myfile").style.visibility = "visible";  
 // sets the browse file to be seen  
        
        
     
        
}






function remove(){
    document.getElementById("myfile").style.visibility = "hidden";
    //sets the browse file to be hidden
}