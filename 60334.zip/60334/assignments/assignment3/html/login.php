<html>
<body>
<?php // login.php
    $hn = 'localhost'; //hostname
    $db = 'wehelie_pbl'; //database
    $un = 'wehelie_pbl'; //username
   $pw = 'mypassword'; //password
?>
</body>
</html>